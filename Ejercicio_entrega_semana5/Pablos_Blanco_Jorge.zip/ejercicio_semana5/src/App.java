import modelo.Almacen;
import modelo.Autor;
import modelo.Libro;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Almacen almacen = null;

        while (true) {
            System.out.println("|----------------------------------------------|");
            System.out.println("| MIS LIBROS PROGRAMACION III - JORGE PABLOS   |");
            System.out.println("|----------------------------------------------|");
            System.out.println("1) Crear Nuevo Almacén de Libros");
            System.out.println("2) Establecer Ritmo de Lectura");
            System.out.println("3) Añadir un Nuevo Libro al Almacén");
            System.out.println("4) Mostrar Info Actual de los Libros");
            System.out.println("5) Salir (Borrar info actual)");
            System.out.println("|----------------------------------------------|");
            System.out.print("Seleccione una opción (1-5): ");


            //REcogemos la opcion del usser y la metemos en el switch
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiamos el buffer

            switch (opcion) {
                case 1: //crear
                    System.out.print("Ingrese el tamaño del almacén: ");
                    int tamaño = scanner.nextInt();
                    almacen = new Almacen(tamaño);
                    System.out.println("Nuevo almacén creado.");
                    break;

                case 2: //ritmo, como es un atributo de almacen, comprobamos que haya uno creado
                    System.out.print("Ingrese el ritmo de lectura (páginas por minuto): ");
                    int ritmo = scanner.nextInt();
                    if (almacen != null) {
                        almacen.establecerRitmoLectura(ritmo);
                        System.out.println("Ritmo de lectura actualizado.");
                    } else {
                        System.out.println("Primero crea un almacén.");
                    }
                    break;

                case 3: //meter libro
                    if (almacen != null) {
                        System.out.print("Ingrese el nombre del autor: ");
                        String nombre = scanner.nextLine();
                        System.out.print("Ingrese los apellidos del autor: ");
                        String apellidos = scanner.nextLine();
                        System.out.print("¿Ha ganado el premio Planeta? (true/false): ");
                        boolean premioPlaneta = scanner.nextBoolean();
                        scanner.nextLine(); // Limpiar buffer
                        
                        Autor autor = new Autor(nombre, apellidos, premioPlaneta); //rellenamos la clase autor de este libro

                        System.out.print("Ingrese el título del libro: ");
                        String titulo = scanner.nextLine();
                        System.out.print("Ingrese el año de publicación: ");
                        int año = scanner.nextInt();
                        System.out.print("Ingrese el número de páginas: ");
                        int paginas = scanner.nextInt();
                        System.out.print("Ingrese el precio: ");
                        double precio = scanner.nextDouble();
                        scanner.nextLine(); // Limpiar buffer

                        Libro libro = new Libro(autor, titulo, año, paginas, precio); //Rellenamos la clase libro CON LA CLASE YA RELLENA AUTOR.


                            //moiramos si hay  hueco para el libro.
                        if (almacen.añadirLibro(libro)) {
                            System.out.println("Libro añadido.");
                        } else {
                            System.out.println("El almacén está lleno.");
                        }

                    } else {
                        System.out.println("Primero cree un almacén.");
                    }
                    break;

                case 4:  //mostramos info total
                    if (almacen != null) {
                        almacen.mostrarLibros();
                        System.out.println("");
                        System.out.println("Tiempo total de lectura: " + almacen.tiempoTotalLectura() + " minutos");
                        System.out.println("Valor total del almacén: " + almacen.valorTotalAlmacen() + " €");
                    } else {
                        System.out.println("Primero cree un almacén.");
                    }
                    break;

                case 5: //salir
                    System.out.println("Saliendo... toda la información será borrada.");
                    return;

                default: //caracter no valido (!(1-5))
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        }
    }
}
