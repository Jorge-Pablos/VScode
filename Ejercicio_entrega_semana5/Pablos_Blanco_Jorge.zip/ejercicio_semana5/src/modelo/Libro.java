package modelo;

public class Libro {
    private Autor autor;
    private String titulo;
    private int añoPublicacion;
    private int numeroPaginas;
    private double precio;

    public Libro(Autor autor, String titulo, int añoPublicacion, int numeroPaginas, double precio) {
        this.autor = autor;
        this.titulo = titulo;
        this.añoPublicacion = añoPublicacion;
        this.numeroPaginas = numeroPaginas;
        this.precio = precio;
    }

        //Getters q usaremos para enseñar luego la info d la tabla
    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public double getPrecio() {
        return precio;
    }

    
    public String mostrarInfo() {
        //"| Título | Año | Autor | Premio Planeta | Páginas | Precio |"
        return " | " + titulo + " | " + añoPublicacion + " | " + autor.mostrarInfo() + " | " + autor.getPremioPlaneta() + " | " + numeroPaginas + " páginas | " + precio + " |";
    }
}
