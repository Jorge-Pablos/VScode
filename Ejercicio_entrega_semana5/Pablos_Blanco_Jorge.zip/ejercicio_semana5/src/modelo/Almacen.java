package modelo;


public class Almacen {
    private Libro[] libros; //array de libros, la clase, dentro de cada libro cada autor
    private int contadorLibros = 0;
    private int ritmoLectura = 1; // Páginas por minuto por defecto

    //crear un almacen, es crear el vector de libros de ese tamaño
    public Almacen(int tamaño) {
        libros = new Libro[tamaño];
    }

    //Funcion para velocidad
    public void establecerRitmoLectura(int ritmo) {
        this.ritmoLectura = ritmo;
    }



    //Comprobamos que hay espacio en nuestro almacen, mirando la .length
    public boolean añadirLibro(Libro libro) {
        if (contadorLibros < libros.length) {
            libros[contadorLibros] = libro;
            contadorLibros++;
            return true;
        }
        return false;
    }

    //interface
    public void mostrarLibros() {
        System.out.println("| Título | Año | Autor | Premio Planeta | Páginas | Precio |");
        for (int i = 0; i < contadorLibros; i++) {
            System.out.println(libros[i].mostrarInfo());
        }
    }


    //tiempo
    public int tiempoTotalLectura() {
        int totalPaginas = 0;
        for (int i = 0; i < contadorLibros; i++) {
            totalPaginas += libros[i].getNumeroPaginas();
        }
        return (totalPaginas / ritmoLectura);
    }

    //precio total
    public double valorTotalAlmacen() {
        double totalPrecio = 0;
        for (int i = 0; i < contadorLibros; i++) {
            totalPrecio += libros[i].getPrecio();
        }
        return totalPrecio;
    }
}
